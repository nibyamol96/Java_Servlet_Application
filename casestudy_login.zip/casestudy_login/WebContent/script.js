function namecheck()
{
		var n=document.getElementById('name');
		if(n.value.length==0)
		{
		  var str="Field is requred";
		  document.getElementById('nam').innerHTML=str;
		
		}
		else {
		  document.getElementById('nam').innerHTML="";
		}
}
function addresscheck()
{
			var n=document.getElementById('add');
			if(n.value.length==0)
			{
			  var str="Field is requred";
			  document.getElementById('address').innerHTML=str;
			
			}
			else {
			  document.getElementById('address').innerHTML="";
			}
}
function mobilecheck()
{
			var n=document.getElementById('mobile');
			if(n.value.length<10)
			{
			  var str="Number contain atlest ";
			  document.getElementById('number').innerHTML=str;
			
			}
			else {
			  document.getElementById('number').innerHTML="";
			}
}
function emailcheck(){
  var c=document.getElementById('email');
  if((c.value.includes("@"))&&(c.value.includes("."))){
    var str1="";
    document.getElementById('em').innerHTML=str1;
  }
  else {
    var str1=" Enter valid mail";
    document.getElementById('em').innerHTML=str1;
  }
}

function passwordchecking(){
  var p=document.getElementById('pswd');
  if(p.value.length>=6){

    document.getElementById('pass').innerHTML="";
  }
  else {
    var str3="password must contain atleast 6 charecter";
    document.getElementById('pass').innerHTML=str3;
  }
}

function confirmpassword(){
  var t=document.getElementById('rpswd');
  var pa=document.getElementById('pswd');
  tval=t.value;
  paval=pa.value;
                           
                            
  if(tval==paval){

                            
    document.getElementById('repass').innerHTML="";
  }
  else {
    var str4="password mismatch";
                          
    document.getElementById('repass').innerHTML=str4;
  }
}