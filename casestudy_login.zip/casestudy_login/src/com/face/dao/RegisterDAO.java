package com.face.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import com.face.bo.RegisterBo;

public class RegisterDAO {
	public static final RegisterDAO regdao=new RegisterDAO();
	public static void save(Connection connection,RegisterBo rg) {
		try {
			Statement stmt=connection.createStatement();
			String qry="INSERT INTO register VALUES('"+rg.getFname()+"','"+rg.getAddress()+"','"+rg.getMobile()+"','"+rg.getEmail()+"','"+rg.getUsername()+"','"+rg.getPassword()+"')";
		    int result=stmt.executeUpdate(qry);
		    if(result==1) {
		    	System.out.println("sucessfully registered");
		    }
		    else {
		    	System.out.println(" registration failed");
		    }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
    }
}
